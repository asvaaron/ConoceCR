package com.example.walter.conocecr;



public interface AsyncResponse {
    void processFinish(String output);
}